------------------------------------------------------------
          README for Gantt Chart Template
                  Mar 2, 2009

         Copyright (C) 2007-2009 Vertex42 LLC

http://www.vertex42.com/ExcelTemplates/excel-gantt-chart.html

Version: 1.6.1-C [Commercial Use Version]

------------------------
SYSTEM REQUIREMENTS
------------------------

This Excel spreadsheet should work with most versions of 
Microsoft Excel (with the exception of versions older than 
Excel 97). The zip file also contains versions in 
OpenDocument format (.ods, .odt) for OpenOffice and StarOffice.

------------------------
INSTALLING
------------------------

The spreadsheet requires no "installation".

After extracting the spreadsheet from the "zipped" file, 
just save it somewhere that you'll be able to find it again.

------------------------
TECHNICAL SUPPORT
------------------------

If you experience problems using this spreadsheet,
contact Vertex42 via email, and we will respond to your 
questions as soon as possible.

Visit the following page for contact information:
http://www.vertex42.com/about.html

------------------------
RELEASE NOTES
------------------------

Version 1.6.1 (3/16/2009)
- Changed End Date formula to Start Date + Duration (removed the '-1')
Version 1.6.0
- Released version for Personal Use Only

------------------------
LICENSE AGREEMENT
------------------------
The Commercial End User License Agreement (LicenseAgreement.txt)
for this spreadsheet is contained within the downloaded .zip file.

See Also:
http://www.vertex42.com/licensing/EULA_commercialuse.html


___________________________________________________________________

Thank you for supporting Vertex42.com!

(C) 2005-2009 Vertex42, LLC. All Rights Reserved.

Microsoft ane Microsoft Excel are registered trademarks of Microsoft Corporation. 
All other trademarks are the property of their respective holders.
